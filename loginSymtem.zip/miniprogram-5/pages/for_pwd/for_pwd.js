const db = wx.cloud.database()

Page({
  data: {
    username: "",
    newPwd: "", 
  },

  user(event) {
    this.setData({
      username: event.detail.value
    })
  },

  newPwd(event) {
    this.setData({
      newPwd: event.detail.value
    })
  },

  resetPwd() {
    if (this.data.username !== "" && this.data.newPwd !== "") {
      let username = this.data.username;
      let newPassword = this.data.newPwd;

      db.collection("user").where({
        id: username,
      }).get({
        success: function(res) {
          if (res.data.length != 0) {
            let userId = res.data[0]._id; 
            
            db.collection("user").doc(userId).update({
              data: {
                password: newPassword,
              },
              success: function(res) {
                wx.showToast({
                  title: '密码重置成功',
                }),
                setTimeout(() => { wx.navigateTo({
                  url: '../index/index',
                })
                  
                },1000);
               
              }
            });
          } else {
            wx.showToast({
              title: '用户名不存在',
              icon: "error"
            });
          }
        }
      });
    } else {
      wx.showToast({
        title: '请输入信息',
        icon: "error"
      });
    }
  }
})
