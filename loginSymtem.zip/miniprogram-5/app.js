// app.js
App({
  onLaunch() {
    wx.cloud.init({
      env:"my-wechat-1gr1e6qoe8df849f"
    })  
  },

  globalData: {
    user_openid:"",
    userInfo: null
  }
})
